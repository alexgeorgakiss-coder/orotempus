
window.renderProducts = async function(selector, limit){
  const container = document.querySelector(selector);
  const resp = await fetch('products.json');
  const items = await resp.json();

  const brandSelect = document.querySelector('#brand');
  if(brandSelect && brandSelect.options.length === 1){
    const brands = [...new Set(items.map(i=>i.brand).filter(Boolean))].sort();
    brands.forEach(b=>{
      const opt = document.createElement('option');
      opt.value = b; opt.textContent = b;
      brandSelect.appendChild(opt);
    });
  }

  function render(){
    const q = (document.querySelector('#q')?.value || '').toLowerCase();
    const brand = document.querySelector('#brand')?.value || '';
    const status = document.querySelector('#status')?.value || '';

    let filtered = items.filter(i=>{
      const text = (i.name+' '+(i.brand||'')+' '+(i.ref||'')).toLowerCase();
      const matchesQ = !q || text.includes(q);
      const matchesBrand = !brand || i.brand === brand;
      const matchesStatus = !status || (status==='available' ? !['sold','on-request'].includes(i.status) : i.status === status);
      return matchesQ && matchesBrand && matchesStatus;
    });

    if(limit) filtered = filtered.slice(0, limit);

    container.innerHTML = filtered.map(p=>`
      <article class="card product">
        ${p.status==='sold' ? '<div class="badge sold">SOLD</div>' : (p.status==='on-request' ? '<div class="badge">ON REQUEST</div>' : '')}
        <img src="${p.image}" alt="${p.name}">
        <div class="content">
          <div class="small" style="letter-spacing:.08em">${p.brand || ''} ${p.ref ? '• '+p.ref : ''}</div>
          <h3 style="margin:6px 0 0 0;font-size:1.05rem">${p.name}</h3>
          <div class="price">€${p.price}</div>
        </div>
      </article>
    `).join('');
  }

  ['#q','#brand','#status'].forEach(sel=>{
    const el = document.querySelector(sel);
    if(el) el.addEventListener('input', render);
  });

  render();
}
